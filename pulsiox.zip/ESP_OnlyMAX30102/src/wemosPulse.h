#ifndef wemos_pulse_h_
#define wemos_pulse_h_
#include <ESP8266WiFi.h>
#include "Arduino.h"
#include "debugutils.h"
#include "wemosMaxConfig.h"
#include "algoritm.h"
#define mySerial Serial
#define DEBUGMIO
void setup();
void loop();
#endif
